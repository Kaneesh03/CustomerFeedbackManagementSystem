document.addEventListener('DOMContentLoaded', function () {
    const ctx = document.getElementById('ratingChart').getContext('2d');
    const ratingChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Smartphone', 'Coffee Maker'],
            datasets: [{
                label: 'Average Rating',
                data: [4, 3], // Sample data
                backgroundColor: ['#007bff', '#28a745'],
                borderColor: ['#0056b3', '#1e7e34'],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    max: 5
                }
            }
        }
    });
});