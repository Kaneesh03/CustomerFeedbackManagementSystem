<?php
require '../includes/config.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit;
}

// Initialize message variable for feedback
$message = '';

// Handle add customer operation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_customer'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $registration_date = $_POST['registration_date'];
    $stmt = $conn->prepare("INSERT INTO customers (name, email, phone, gender, registration_date) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $phone, $gender, $registration_date);
    if ($stmt->execute()) {
        $message = '<div class="alert alert-success">Customer added successfully!</div>';
    } else {
        $message = '<div class="alert alert-danger">Error adding customer: ' . $stmt->error . '</div>';
    }
    $stmt->close();
}

// Fetch customers
$customers = mysqli_query($conn, "SELECT * FROM customers");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customers</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 sidebar bg-primary text-white">
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item"><a class="nav-link text-white" href="dashboard.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link text-white" href="customers.php">Customers</a></li>
                        <li class="nav-item"><a class="nav-link text-white" href="products.php">Products</a></li>
                        <li class="nav-item"><a class="nav-link text-white" href="feedback.php">Feedback</a></li>
                        <li class="nav-item"><a class="nav-link text-white" href="analytics.php">Analytics</a></li>
                        <li class="nav-item"><a class="nav-link text-white" href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </nav>
            <main class="col-md-10 ms-sm-auto px-md-4">
                <h2 class="mt-4">Manage Customers</h2>
                <?php if ($message) echo $message; ?>
                <!-- Add Customer Form -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5>Add New Customer</h5>
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-2 mb-3">
                                    <label for="name">Name</label>
                                    <input type="text" id="name" name="name" class="form-control" required>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="email">Email</label>
                                    <input type="email" id="email" name="email" class="form-control" required>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label for="phone">Phone</label>
                                    <input type="text" id="phone" name="phone" class="form-control">
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label for="gender">Gender</label>
                                    <select id="gender" name="gender" class="form-control" required>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="registration_date">Registration Date</label>
                                    <input type="date" id="registration_date" name="registration_date" class="form-control" required>
                                </div>
                            </div>
                            <button type="submit" name="add_customer" class="btn btn-primary">Add Customer</button>
                        </form>
                    </div>
                </div>
                <!-- Customer List -->
                <div class="card">
                    <div class="card-body">
                        <h5>Customer List</h5>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Gender</th>
                                    <th>Registration Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($customers)) { ?>
                                    <tr>
                                        <td><?php echo $row['customer_id']; ?></td>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                        <td><?php echo $row['gender']; ?></td>
                                        <td><?php echo $row['registration_date']; ?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>
</html>