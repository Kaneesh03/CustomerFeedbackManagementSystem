<?php
require '../includes/config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Fetch analytics data
$avg_ratings = mysqli_query($conn, "SELECT p.name, AVG(f.rating) as avg_rating FROM feedback f JOIN products p ON f.product_id = p.product_id GROUP BY p.product_id");
$total_feedback = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM feedback"));

// Feedback trend data (monthly)
$trend_data = mysqli_query($conn, "SELECT DATE_FORMAT(submission_date, '%Y-%m') as month, COUNT(*) as count FROM feedback GROUP BY month ORDER BY month");
$trend_labels = [];
$trend_counts = [];
while ($row = mysqli_fetch_assoc($trend_data)) {
    $trend_labels[] = $row['month'];
    $trend_counts[] = $row['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Analytics</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 sidebar bg-primary text-white">
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item"><a class="nav-link text-white" href="dashboard.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link text-white" href="customers.php">Customers</a></li>
                        <li class="nav-item"><a class="nav-link text-white" href="products.php">Products</a></li>
                        <li class="nav-item"><a class="nav-link text-white" href="feedback.php">Feedback</a></li>
                        <li class="nav-item"><a class="nav-link text-white" href="analytics.php">Analytics</a></li>
                        <li class="nav-item"><a class="nav-link text-white" href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </nav>
            <main class="col-md-10 ms-sm-auto px-md-4">
                <h2 class="mt-4">Analytics Dashboard</h2>
                <div class="row">
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5>Average Rating per Product</h5>
                                <canvas id="ratingChart"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5>Feedback Trends Over Time</h5>
                                <canvas id="trendChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h5>Feedback Summary</h5>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Average Rating</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($avg_ratings)) { ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo round($row['avg_rating'], 1); ?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                        <p><strong>Total Feedback Received:</strong> <?php echo $total_feedback; ?></p>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script>
        // Rating Chart
        const ratingCtx = document.getElementById('ratingChart').getContext('2d');
        new Chart(ratingCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column(mysqli_fetch_all($avg_ratings, MYSQLI_ASSOC), 'name')); ?>,
                datasets: [{
                    label: 'Average Rating',
                    data: <?php echo json_encode(array_column(mysqli_fetch_all($avg_ratings, MYSQLI_ASSOC), 'avg_rating')); ?>,
                    backgroundColor: ['#007bff', '#28a745', '#ffc107', '#dc3545'],
                    borderColor: ['#0056b3', '#1e7e34', '#e0a800', '#c82333'],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 5
                    }
                }
            }
        });

        // Trend Chart
        const trendCtx = document.getElementById('trendChart').getContext('2d');
        new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($trend_labels); ?>,
                datasets: [{
                    label: 'Feedback Count',
                    data: <?php echo json_encode($trend_counts); ?>,
                    borderColor: '#007bff',
                    fill: false
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>