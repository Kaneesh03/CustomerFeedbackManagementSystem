<?php
require '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_id = $_POST['customer_id'];
    $product_id = $_POST['product_id'];
    $rating = $_POST['rating'];
    $comments = $_POST['comments'];
    $suggestions = $_POST['suggestions'];
    $submission_date = date('Y-m-d H:i:s');

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO feedback (customer_id, product_id, rating, comments, suggestions, submission_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iiisss", $customer_id, $product_id, $rating, $comments, $suggestions, $submission_date);
    
    if ($stmt->execute()) {
        $stmt->close();
        header('Location: thank_you.php');
        exit;
    } else {
        $error = "Error submitting feedback: " . $stmt->error;
        $stmt->close();
    }
}

// Determine back button URL based on login status
$back_url = isset($_SESSION['user_id']) ? '../admin/dashboard.php' : '../index.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Feedback</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-body">
                <h3>Submit Feedback</h3>
                <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
                <form method="POST">
                    <div class="mb-3">
                        <label for="customer_id">Customer</label>
                        <select name="customer_id" id="customer_id" class="form-control" required>
                            <?php
                            $result = mysqli_query($conn, "SELECT * FROM customers");
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='{$row['customer_id']}'>" . htmlspecialchars($row['name']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="product_id">Product</label>
                        <select name="product_id" id="product_id" class="form-control" required>
                            <?php
                            $result = mysqli_query($conn, "SELECT * FROM products WHERE status='Active'");
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='{$row['product_id']}'>" . htmlspecialchars($row['name']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="rating">Rating</label>
                        <select name="rating" id="rating" class="form-control" required>
                            <option value="1">1 Star</option>
                            <option value="2">2 Stars</option>
                            <option value="3">3 Stars</option>
                            <option value="4">4 Stars</option>
                            <option value="5">5 Stars</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="comments">Comments</label>
                        <textarea name="comments" id="comments" class="form-control" rows="4"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="suggestions">Suggestions</label>
                        <textarea name="suggestions" id="suggestions" class="form-control" rows="4"></textarea>
                    </div>
                    <div class="d-flex justify-content-between">
                        <button type="submit" class="btn btn-primary">Submit Feedback</button>
                        <a href="<?php echo $back_url; ?>" class="btn btn-secondary">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>