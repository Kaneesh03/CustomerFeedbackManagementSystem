<?php
// DB connection settings
$host = "localhost";
$user = "root";  // Default XAMPP username
$password = "";
$dbname = "feedback_system";

// Create DB connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get all feedback
$sql = "SELECT id, name, email, message, created_at FROM feedback ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Feedback Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 30px;
        }
        h2 {
            text-align: center;
        }
        table {
            border-collapse: collapse;
            width: 90%;
            margin: 20px auto;
            background-color: white;
            box-shadow: 0 0 10px #ccc;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 12px 15px;
            text-align: left;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .no-data {
            text-align: center;
            margin-top: 50px;
            font-size: 18px;
            color: #777;
        }
    </style>
</head>
<body>

<h2>User Feedback Dashboard</h2>

<?php if ($result && $result->num_rows > 0): ?>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Message</th>
            <th>Date</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row["id"]) ?></td>
            <td><?= htmlspecialchars($row["name"]) ?></td>
            <td><?= htmlspecialchars($row["email"]) ?></td>
            <td><?= nl2br(htmlspecialchars($row["message"])) ?></td>
            <td><?= htmlspecialchars($row["created_at"]) ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <div class="no-data">No feedback found.</div>
<?php endif; ?>

<?php $conn->close(); ?>

</body>
</html>
