<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'feedback_system');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>