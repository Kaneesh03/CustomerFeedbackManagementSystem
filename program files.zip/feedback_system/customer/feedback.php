<?php
require '../includes/config.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_id = $_POST['customer_id'];
    $product_id = $_POST['product_id'];
    $rating = $_POST['rating'];
    $comments = $_POST['comments'];
    $suggestions = $_POST['suggestions'];
    $submission_date = date('Y-m-d H:i:s');
    $query = "INSERT INTO feedback (customer_id, product_id, rating, comments, suggestions, submission_date) VALUES ('$customer_id', '$product_id', '$rating', '$comments', '$suggestions', '$submission_date')";
    if (mysqli_query($conn, $query)) {
        header('Location: thank_you.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Feedback</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-body">
                <h3>Submit Feedback</h3>
                <form method="POST">
                    <div class="mb-3">
                        <label>Customer</label>
                        <select name="customer_id" class="form-control" required>
                            <?php
                            $result = mysqli_query($conn, "SELECT * FROM customers");
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='{$row['customer_id']}'>{$row['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Product</label>
                        <select name="product_id" class="form-control" required>
                            <?php
                            $result = mysqli_query($conn, "SELECT * FROM products WHERE status='Active'");
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='{$row['product_id']}'>{$row['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Rating</label>
                        <select name="rating" class="form-control" required>
                            <option value="1">1 Star</option>
                            <option value="2">2 Stars</option>
                            <option value="3">3 Stars</option>
                            <option value="4">4 Stars</option>
                            <option value="5">5 Stars</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Comments</label>
                        <textarea name="comments" class="form-control" rows="4"></textarea>
                    </div>
                    <div class="mb-3">
                        <label>Suggestions</label>
                        <textarea name="suggestions" class="form-control" rows="4"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Feedback</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>