<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Feedback System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container text-center mt-5">
        <img src="assets/images/logo.png" alt="Logo" class="img-fluid mb-3" style="max-width: 150px;">
        <h1>Customer Feedback System</h1>
        <p>Collect and manage customer feedback efficiently.</p>
        <div class="mt-4">
            <a href="admin/login.php" class="btn btn-primary">Admin/Staff Login</a>
            <a href="customer/feedback.php" class="btn btn-success">Submit Feedback</a>
        </div>
    </div>
</body>
</html>