-- Create Database
CREATE DATABASE feedback_system;
USE feedback_system;

-- Customers Table
CREATE TABLE customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    registration_date DATE NOT NULL
);

-- Products Table
CREATE TABLE products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT,
    status ENUM('Active', 'Inactive') DEFAULT 'Active'
);

-- Feedback Table
CREATE TABLE feedback (
    feedback_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    product_id INT,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comments TEXT,
    suggestions TEXT,
    submission_date DATETIME NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
    is_important BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Admin/Staff Table
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'Staff') NOT NULL
);

-- Sample Data
INSERT INTO customers (name, email, phone, gender, registration_date) VALUES
('John Doe', 'john@example.com', '1234567890', 'Male', '2025-01-01'),
('Jane Smith', 'jane@example.com', '0987654321', 'Female', '2025-02-01');

INSERT INTO products (name, category, description, status) VALUES
('Smartphone', 'Electronics', 'Latest model smartphone', 'Active'),
('Coffee Maker', 'Appliances', 'Automatic coffee machine', 'Active');

INSERT INTO feedback (customer_id, product_id, rating, comments, suggestions, submission_date, status) VALUES
(1, 1, 4, 'Great phone, good battery life', 'Add more color options', '2025-03-01 10:00:00', 'Approved'),
(2, 2, 3, 'Coffee maker is okay', 'Improve brewing speed', '2025-03-02 12:00:00', 'Pending');

INSERT INTO users (username, password, role) VALUES
('admin', 'admin123', 'Admin'),
('staff', 'staff123', 'Staff');
CREATE TABLE customer_users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

INSERT INTO customers (name, email, phone, gender, registration_date) 
VALUES ('John Doe', 'john@example.com', '1234567890', 'Male', '2025-05-28');

INSERT INTO customer_users (customer_id, email, password) 
VALUES (LAST_INSERT_ID(), 'john@example.com', 'customer123');